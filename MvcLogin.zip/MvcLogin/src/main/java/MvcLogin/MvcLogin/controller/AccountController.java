package MvcLogin.MvcLogin.controller;


import MvcLogin.MvcLogin.model.AppUser;
import MvcLogin.MvcLogin.model.RegistrationDto;
import MvcLogin.MvcLogin.repository.AppUserRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Date;

@Controller
public class AccountController {

    @Autowired
    private AppUserRepository appUserRepository;

    @GetMapping("/register")
    public String register(Model model){
        RegistrationDto registrationDto = new RegistrationDto();
        model.addAttribute(registrationDto);
        return "register";
    }

    @PostMapping("/register")
    public String register(Model model, @Valid @ModelAttribute RegistrationDto registrationDto, BindingResult result){

        if (!registrationDto.getPassword().equals(registrationDto.getConfirmPassword())){
            result.addError(new FieldError("registrationDto","confirmPassword","Password and confirm Password do not match"));
        }

        AppUser appUser = appUserRepository.findByEmail(registrationDto.getEmail());
        if (appUser!=null){
            result.addError(new FieldError("registrationDto","email","Email address is already used"));
        }

        if (result.hasErrors()){
            return "register";
        }

        try{

            var bcryptEncoder= new BCryptPasswordEncoder();

            AppUser appUser1 =new AppUser();
            appUser1.setFirstName(registrationDto.getFirstName());
            appUser1.setLastName(registrationDto.getLastName());
            appUser1.setEmail(registrationDto.getEmail());
            appUser1.setPhone(registrationDto.getPhone());
            appUser1.setAddress(registrationDto.getAddress());
            appUser1.setRole("client");
            appUser1.setCreatedAt(new Date());
            appUser1.setPassword(bcryptEncoder.encode(registrationDto.getPassword()));
            appUserRepository.save(appUser1);
        }catch (Exception e){
            result.addError(new FieldError("registrationDto","firstName",e.getMessage()));
        }
            return "register";
    }
}
