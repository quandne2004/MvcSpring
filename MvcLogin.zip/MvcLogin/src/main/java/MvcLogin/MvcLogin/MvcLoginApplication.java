package MvcLogin.MvcLogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcLoginApplication.class, args);
	}

}
